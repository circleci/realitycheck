(function(_, $) {

    var preset_id, object_type,
        delimiter_selector, company_selector,
        file_type_selector, file_selector;

    var methods = {
        init_preset_editor: function() {

            delimiter_selector.on('change', function(){
                if ($('#import_preset_update_form').find('input[name^=type_upload]').val() !== 'local') {
                    $.ceAdvancedImport('get_fields');
                }
            });

            $.ceEvent('on', 'ce.fileuploader.display_filename', function(id, file_type, file) {
                if (file_type === 'server' || file_type === 'url') {
                    file = $('#file_' + id).val();
                    $.ceAdvancedImport('get_fields', file_type, file);
                    $('#advanced_import_save_and_import, li#fields').removeClass('hidden');
                } else if (file_type === 'local') {
                    $('li#fields').addClass('hidden');
                }
            });
        },

        get_fields: function(file_type, file) {

            file_type = file_type || file_type_selector.val();
            file = file || file_selector.val();

            var options = {};
            if (delimiter_selector.length) {
                options.delimiter = delimiter_selector.val()
            }

            var company_id = company_selector.val();

            var data = {
                preset_id: preset_id,
                object_type: object_type,
                options: options,
                company_id: company_id
            };
            if (file_type) {
                data.file_type = file_type;
            }
            if (file) {
                data.file = file;
            }

            $.ceAjax('request', fn_url('import_presets.get_fields'), {
                result_ids: 'content_fields',
                caching: false,
                data: data,
                callback: function(response) {
                    response.has_fields = response.has_fields || false;
                    $('.tabs #fields').addClass('cm-ajax-onclick-active').toggleClass('hidden', !response.has_fields);
                }
            });
        },

        init_related_object_selectors: function(selectors) {
            selectors.change(function() {
                var type_holder = $('#elm_field_related_object_type_' + $(this).data('caAdvancedImportFieldId'));
                var type = $('option:selected', $(this)).data('caAdvancedImportFieldRelatedObjectType');
                type_holder.val(type);
            });

            selectors.each(function() {
                $(this).trigger('change');
            });
        },

        show_fields_preview: function(opener) {
            var params = $.ceDialog('get_params', opener);
            $('#' + opener.data('caTargetId')).ceDialog('open', params);
            if (window.history.replaceState) {
                window.history.replaceState({}, '', _.current_url.replace(/&preview_preset_id=\d+/, ''));
            }
        },

        // FIXME: Dirty hack
        // Pop-up with the fields mapping is destroyed before a Comet request is sent,
        // so fields must be manually transfered to the parent form.
        set_fields_for_import: function(preset_id) {
            var form = $('[data-ca-advanced-import-element="management_form"]');

            form.append('<input type="hidden" name="preset_id" value="' + preset_id + '" />');
            form.append('<input type="hidden" name="dispatch[advanced_import.import]" value="OK" />');

            var fields = form.serializeArray();

            for (var i in fields) {
                var field = fields[i];
                if (/^fields\[/.test(field.name)) {
                    form.append($('<input>', {
                        type: "hidden",
                        name: field.name,
                        value: field.value
                    }));
                }
            }
        }
    };

    $.extend({
        ceAdvancedImport: function(method) {
            if (methods[method]) {
                return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
            } else {
                $.error('ty.advancedImport: method ' + method + ' does not exist');
            }
        }
    });

    $.ceEvent('on', 'ce.commoninit', function(context) {
        var preset = $('[data-ca-advanced-import-element="editor"]', context);

        if (preset.length) {
            preset_id = preset.data('caAdvancedImportPresetId');
            object_type = preset.data('caAdvancedImportPresetObjectType');
            delimiter_selector = $('[data-ca-advanced-import-element="delimiter_container"] select', context);
            company_selector = $('#elm_company_id', context);
            file_type_selector = $('[name="type_upload[]"]');
            file_selector = $('[name="file_upload[]"]');

            $.ceAdvancedImport('init_preset_editor');
        }

        var related_object_selectors = $('[data-ca-advanced-import-field-related-object-selector]', context);

        if (related_object_selectors.length) {
            $.ceAdvancedImport('init_related_object_selectors', related_object_selectors);
        }

        var fields_preview_opener = $('.import-preset__preview-fields-mapping', context);

        if (fields_preview_opener.length) {
            $.ceAdvancedImport('show_fields_preview', fields_preview_opener);
        }

        var import_start_button = $('.cm-advanced-import-start-import', context);

        if (import_start_button.length) {
            import_start_button.click();
        }
    });
})(Tygh, Tygh.$);