<?php
/***************************************************************************
*                                                                          *
*   (c) 2004 Vladimir V. Kalynyak, Alexey V. Vinokurov, Ilya M. Shalnev    *
*                                                                          *
* This  is  commercial  software,  only  users  who have purchased a valid *
* license  and  accept  to the terms of the  License Agreement can install *
* and use this program.                                                    *
*                                                                          *
****************************************************************************
* PLEASE READ THE FULL TEXT  OF THE SOFTWARE  LICENSE   AGREEMENT  IN  THE *
* "copyright.txt" FILE PROVIDED WITH THIS DISTRIBUTION PACKAGE.            *
****************************************************************************/

namespace Tygh\Addons\AdvancedImport\Readers;

use Tygh\Enum\Addons\AdvancedImport\CsvDelimiters;

class Csv implements IReader
{
    /** @var string $path */
    protected $path;

    /** @var array $options */
    protected $options = array();

    /** @var int $max_line_size */
    protected $max_line_size = 65536;

    /** @var int $sample_size */
    protected $sample_size = 5;

    /** @inheritdoc */
    public function __construct($path, array $options = array())
    {
        $this->path = $path;
        $this->options = $options;
    }

    /** @inheritdoc */
    public function getSchema()
    {
        $delimiters = $this->getDelimiters();

        $file = fopen($this->path, 'rb');
        $result = array();

        foreach ($delimiters as $delimiter => $literal_delimiter) {
            $schema = fgetcsv($file, $this->max_line_size, $literal_delimiter);
            if ($schema && count($schema) > 1) {
                $this->options['delimiter'] = $delimiter;
                $result = $this->normalizeSchema($schema);
                break;
            }
            fseek($file, 0);
        }

        fclose($file);

        return $result;
    }

    /**
     * Gets list of delimiter to parse file with.
     *
     * @return array
     */
    protected function getDelimiters()
    {
        $all_delimiters = CsvDelimiters::getAll();

        if (isset($this->options['delimiter'])) {
            $delimiters = array($this->options['delimiter'] => $all_delimiters[$this->options['delimiter']]);
        } else {
            $delimiters = $all_delimiters;
        }

        return $delimiters;
    }

    /** @inheritdoc */
    public function getContents($count = null, array $schema = null)
    {
        $delimiters = $this->getDelimiters();

        if ($schema === null) {
            $schema = $this->getSchema();
        }

        if (!$schema) {
            return array();
        }

        foreach ($delimiters as $delimiter => $literal_delimiter) {
            $contents = fn_exim_get_csv(array(), $this->path, array(
                'validate_schema' => false,
                'import_schema'   => $schema,
                'count'           => $count,
                'delimiter'       => $delimiter,
            ));
            if ($contents && count($contents[0]) > 1) {
                $this->options['delimiter'] = $delimiter;

                return $contents;
            }
        }

        return array();
    }

    /** @inheritdoc */
    public function getApproximateLinesCount()
    {
        $filesize = filesize($this->path);

        $file = fopen($this->path, 'rb');

        $aggregate_sample_size = 0;
        $sample_lines_count = 0;
        $is_header_read = false;

        while (($sample = fgets($file, $this->max_line_size)) && $sample_lines_count < $this->sample_size) {
            $sample_size = count(unpack('C*', $sample));

            // skip header
            if (!$is_header_read) {
                $filesize -= $sample_size;
                $is_header_read = true;
                continue;
            }

            $aggregate_sample_size += $sample_size;
            $sample_lines_count++;
        }

        fclose($file);

        $approx_count = ceil($filesize / $aggregate_sample_size * $sample_lines_count);

        return $approx_count ?: 1;
    }

    /**
     * Normalizes field names to store them in the database: removes linebreaks and trims content.
     *
     * @param array $schema Import file fields description
     *
     * @return array
     */
    protected function normalizeSchema(array $schema)
    {
        foreach ($schema as &$field) {
            $field = trim(preg_replace('/\s+/', ' ', $field));
        }
        unset($field);

        return $schema;
    }
}