<?php
/***************************************************************************
 *                                                                          *
 *   (c) 2004 Vladimir V. Kalynyak, Alexey V. Vinokurov, Ilya M. Shalnev    *
 *                                                                          *
 * This  is  commercial  software,  only  users  who have purchased a valid *
 * license  and  accept  to the terms of the  License Agreement can install *
 * and use this program.                                                    *
 *                                                                          *
 ****************************************************************************
 * PLEASE READ THE FULL TEXT  OF THE SOFTWARE  LICENSE   AGREEMENT  IN  THE *
 * "copyright.txt" FILE PROVIDED WITH THIS DISTRIBUTION PACKAGE.            *
 ****************************************************************************/

defined('BOOTSTRAP') or die('Access denied');

if (isset($schema['export_fields'])) {
    $schema['export_fields']['Advanced Import: Features'] = array(
        'process_put' => array('fn_advanced_import_set_product_features', '#key', '#this', '@features_delimiter'),
        'linked'      => false,
        'multilang'   => true,
        'import_only' => true,
        'hidden'      => true,
    );
    $schema['export_fields']['Advanced Import: Images'] = array(
        'process_put' => array(
            'fn_advanced_import_set_product_images',
            '#key',
            '#this',
            '@images_path',
            '@images_delimiter',
            '@remove_images',
        ),
        'linked'      => false,
        'import_only' => true,
    );
}

if (isset($schema['options'])) {
    $schema['options']['skip_creating_new_products']['is_separate'] =
    $schema['options']['reset_inventory']['is_separate'] =
    $schema['options']['delete_files']['is_separate'] = true;

    $schema['options']['images_delimiter'] = array(
        'title'         => 'advanced_import.images_delimiter',
        'description'   => 'advanced_import.images_delimiter.description',
        'type'          => 'input',
        'default_value' => '///',
    );

    $schema['options']['remove_images'] = array(
        'title'       => 'advanced_import.remove_images',
        'description' => 'text_remove_additional_images',
        'type'        => 'checkbox',
        'import_only' => true,
        'is_separate' => true,
    );
}

return $schema;