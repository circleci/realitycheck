<?php
/***************************************************************************
 *                                                                          *
 *   (c) 2004 Vladimir V. Kalynyak, Alexey V. Vinokurov, Ilya M. Shalnev    *
 *                                                                          *
 * This  is  commercial  software,  only  users  who have purchased a valid *
 * license  and  accept  to the terms of the  License Agreement can install *
 * and use this program.                                                    *
 *                                                                          *
 ****************************************************************************
 * PLEASE READ THE FULL TEXT  OF THE SOFTWARE  LICENSE   AGREEMENT  IN  THE *
 * "copyright.txt" FILE PROVIDED WITH THIS DISTRIBUTION PACKAGE.            *
 ****************************************************************************/

defined('BOOTSTRAP') or die('Access denied');

use Tygh\Addons\AdvancedImport\Exceptions\FileNotFoundException;
use Tygh\Addons\AdvancedImport\Exceptions\ReaderNotFoundException;
use Tygh\Enum\Addons\AdvancedImport\PresetFileTypes;
use Tygh\Exceptions\PermissionsException;
use Tygh\Registry;
use Tygh\Tools\Url;

/** @var string $mode */

/** @var \Tygh\Addons\AdvancedImport\Presets\Manager $presets_manager */
$presets_manager = Tygh::$app['addons.advanced_import.presets.manager'];
/** @var \Tygh\Addons\AdvancedImport\Presets\Importer $presets_importer */
$presets_importer = Tygh::$app['addons.advanced_import.presets.importer'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    /** @var \Tygh\Addons\AdvancedImport\Readers\Factory $file_uploader */
    $file_uploader = Tygh::$app['addons.advanced_import.readers.factory'];

    if ($mode == 'upload') {
        $preset = array_merge(array(
            'preset_id' => 0,
            'file_type' => PresetFileTypes::LOCAL,
            'file'      => '',
        ), $_REQUEST);

        $file = fn_filter_uploaded_data('upload');

        if ($file) {
            $preset['preset_id'] = key($file);
            $file = reset($file);
            $preset['file'] = $file_uploader->getTemporaryName($preset['preset_id'], fn_get_file_ext($file['name']));
            unset($preset['type_upload'], $preset['file_upload']);
        } else {
            fn_set_notification('E', __('error'), __('error_exim_no_file_uploaded'));
            exit;
        }

        $presets_manager->update($preset['preset_id'], $preset);

        list($presets,) = $presets_manager->find(false, array('ip.preset_id' => $preset['preset_id']), false);
        $preset = reset($presets);

        $file_uploader->moveUpload($preset['file'], $file['path'], $preset['company_id']);

        $redirect_url = Url::buildUrn(array('import_presets', 'manage'), array(
            'object_type'       => $preset['object_type'],
            'preview_preset_id' => $preset['preset_id'],
        ));

        Tygh::$app['ajax']->assign('force_redirection', fn_url($redirect_url));
        exit;
    }

    if ($mode == 'update') {

        $preset = array_merge(array(
            'preset_id' => 0,
            'file_type' => PresetFileTypes::LOCAL,
            'file'      => '',
        ), $_REQUEST);

        $file = fn_filter_uploaded_data('upload');

        if ($file) {
            $file = reset($file);

            $preset['file_type'] = reset($preset['type_upload']);
            $preset['file'] = reset($preset['file_upload']);
            unset($preset['type_upload'], $preset['file_upload']);
        }

        if ($preset['preset_id']) {
            $presets_manager->update($preset['preset_id'], $preset);
        } else {
            $preset['preset_id'] = $presets_manager->add($preset);
        }

        list($presets,) = $presets_manager->find(false, array('ip.preset_id' => $preset['preset_id']), false);
        $preset = reset($presets);

        if ($file && $preset['file_type'] == PresetFileTypes::LOCAL) {
            // rename temporary file for a preset
            $preset['file'] = $file_uploader->getTemporaryName($preset['preset_id'], fn_get_file_ext($file['name']));
            $file_uploader->moveUpload($preset['file'], $file['path'], $preset['company_id']);
            $presets_manager->update($preset['preset_id'], $preset);
        }

        $redirect_url = 'import_presets.update?preset_id=' . $preset['preset_id'];

        if ($action == 'import') {
            $redirect_url .= '&start_import=1';
        }

        return array(CONTROLLER_STATUS_OK, $redirect_url);
    } elseif ($mode == 'm_delete') {
        $_REQUEST = array_merge(array(
            'preset_ids'   => array(),
            'object_type'  => 'products',
            'redirect_url' => 'import_presets.manage',
        ), $_REQUEST);

        foreach ($_REQUEST['preset_ids'] as $preset_id) {
            $presets_manager->delete($preset_id);
        }

        return array(CONTROLLER_STATUS_OK, $_REQUEST['redirect_url']);
    } elseif ($mode == 'delete') {

        $_REQUEST = array_merge(array(
            'preset_id' => 0,
        ), $_REQUEST);

        list($presets,) = $presets_manager->find(
            false,
            array('ip.preset_id' => $_REQUEST['preset_id'])
        );

        if (!$presets) {
            return array(CONTROLLER_STATUS_NO_PAGE);
        }

        $preset = reset($presets);

        $presets_manager->delete($_REQUEST['preset_id']);

        return array(CONTROLLER_STATUS_OK, 'import_presets.manage?object_type=' . $preset['object_type']);
    }
}

if ($mode == 'update'
    || $mode == 'add'
    || $mode == 'get_fields'
) {
    /** @var \Tygh\Addons\AdvancedImport\Readers\Factory $reader_factory */
    $file_uploader = Tygh::$app['addons.advanced_import.readers.factory'];
    foreach (fn_get_short_companies() as $company_id => $company_name) {
        $file_uploader->initFilesDirectories($company_id);
    }
}

if ($mode == 'manage') {
    $params = array_merge(array(
        'page'              => 1,
        'items_per_page'    => Registry::get('settings.Appearance.admin_elements_per_page'),
        'object_type'       => 'products',
        'preview_preset_id' => 0,
    ), $_REQUEST);

    list($presets, $search) = fn_get_import_presets($params);

    if ($presets) {
        list($modifiers_presense,) = $presets_manager->find(
            false,
            array(
                array('modifier', '<>', ''),
                'ipf.preset_id' => array_keys($presets),
            ),
            array(
                array(
                    'table'     => array('?:import_preset_fields' => 'ipf'),
                    'condition' => array('ip.preset_id = ipf.preset_id'),
                ),
                array(
                    'table'     => array('?:import_preset_descriptions' => 'ipd'),
                    'condition' => array('ip.preset_id = ipd.preset_id'),
                ),
            ),
            array(
                'COUNT(ipf.field_id)' => 'has_modifiers',
            )
        );

        $presets = fn_array_merge($presets, $modifiers_presense);

        /** @var \Tygh\Addons\AdvancedImport\Readers\Factory $reader_factory */
        $reader_factory = Tygh::$app['addons.advanced_import.readers.factory'];

        foreach ($presets as &$preset) {
            if ($preset['file_type'] == PresetFileTypes::SERVER) {
                $preset['file_path'] = $reader_factory->getFilePath($preset['file'], $preset['company_id']);
            }
        }
        unset($preset);
    }

    Tygh::$app['view']->assign(array(
        'presets'           => $presets,
        'search'            => $search,
        'object_type'       => $params['object_type'],
        'preview_preset_id' => $params['preview_preset_id'],
    ));
} elseif ($mode == 'add') {

    $preset = array_merge(array(
        'object_type' => 'products',
    ), $_REQUEST);

    $pattern = $presets_manager->getPattern($preset['object_type']);
    $preset = $presets_manager->mergePattern($preset, $pattern);

    Registry::set('navigation.tabs', array(
        'general' => array(
            'title' => __('file'),
            'js'    => true,
        ),
        'fields'  => array(
            'title'        => __('advanced_import.fields_mapping'),
            'href'         => 'import_presets.get_fields',
            'ajax'         => true,
            'ajax_onclick' => true,
            'hidden'       => 'Y',
        ),
        'options' => array(
            'title' => __('advanced_import.options'),
            'js'    => true,
        ),
    ));

    Tygh::$app['view']->assign(array(
        'pattern' => $pattern,
        'preset'  => $preset,
    ));
} elseif ($mode == 'update') {

    if (empty($_REQUEST['preset_id'])) {
        return array(CONTROLLER_STATUS_NO_PAGE);
    }

    list($presets) = fn_get_import_presets(array(
        'preset_id' => $_REQUEST['preset_id'],
    ));

    if (!$presets) {
        return array(CONTROLLER_STATUS_NO_PAGE);
    }

    $preset = reset($presets);
    $pattern = $presets_manager->getPattern($preset['object_type']);
    $preset = $presets_manager->mergePattern($preset, $pattern);

    Registry::set('navigation.tabs', array(
        'general' => array(
            'title' => __('file'),
            'js'    => true,
        ),
        'fields'  => array(
            'title'        => __('advanced_import.fields_mapping'),
            'href'         => 'import_presets.get_fields?preset_id=' . $_REQUEST['preset_id'],
            'ajax'         => true,
            'ajax_onclick' => true,
            'hdden'        => ($preset['file_type'] == PresetFileTypes::LOCAL) ? 'Y' : 'N',
        ),
        'options' => array(
            'title' => __('advanced_import.options'),
            'js'    => true,
        ),
    ));

    Tygh::$app['view']->assign(array(
        'pattern'      => $pattern,
        'preset'       => $preset,
        'start_import' => !empty($_REQUEST['start_import']) ? $_REQUEST['start_import'] : false,
    ));
} elseif ($mode == 'get_fields') {

    $preset = array_merge(array(
        'file'        => '',
        'file_type'   => PresetFileTypes::LOCAL,
        'preset_id'   => 0,
        'company_id'  => fn_get_runtime_company_id(),
        'object_type' => 'products',
        'fields'      => array(),
        'options'     => array(),
    ), $_REQUEST);

    if ($preset['preset_id']) {
        list($presets,) = $presets_manager->find(false, array('ip.preset_id' => $preset['preset_id']), false);
        $preset = reset($presets);
        $preset['fields'] = $presets_manager->getFieldsMapping($preset['preset_id']);
        if (isset($_REQUEST['file'])) {
            $preset['file'] = $_REQUEST['file'];
        }
        if (isset($_REQUEST['file_type'])) {
            $preset['file_type'] = $_REQUEST['file_type'];
        }
        if (isset($_REQUEST['options'])) {
            $preset['options'] = array_merge($preset['options'], $_REQUEST['options']);
        }
        if (isset($_REQUEST['company_id'])) {
            $preset['company_id'] = $_REQUEST['company_id'];
        }
    }

    if ($preset['file']) {

        /** @var \Tygh\Addons\AdvancedImport\Readers\Factory $reader_factory */
        $reader_factory = Tygh::$app['addons.advanced_import.readers.factory'];

        /** @var Tygh\Addons\AdvancedImport\Readers\IReader $reader */
        try {
            $reader = $reader_factory->get($preset);
            $fields = $reader->getSchema();

            if ($preview = $reader->getContents(1, $fields)) {
                $preview = $presets_importer->prepareImportItems(
                    $preview,
                    $preset['fields'],
                    $preset['object_type']
                );
            }

            $pattern = $presets_manager->getPattern($preset['object_type']);
            $preset = $presets_manager->mergePattern($preset, $pattern);

            $relations = $presets_manager->getRelations($preset['object_type']);

            Tygh::$app['view']->assign(array(
                'preset'                 => $preset,
                'fields'                 => $fields,
                'preview'                => $preview,
                'relations'              => $relations,
                'show_buttons_container' => $action == 'import',
            ));

            Tygh::$app['ajax']->assign('has_fields', !empty($fields));
        } catch (ReaderNotFoundException $e) {
            fn_set_notification('E', __('error'), __('error_exim_cant_read_file'));
            exit;
        } catch (PermissionsException $e) {
            fn_set_notification('E', __('error'), __('advanced_import.cant_load_file_for_company'));
            exit;
        } catch (FileNotFoundException $e) {
            fn_set_notification('E', __('error'), __('advanced_import.cant_load_file_for_company'));
            exit;
        }
    }
}
