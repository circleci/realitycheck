export { GenericGitAuthentication } from './generic-git-auth'
