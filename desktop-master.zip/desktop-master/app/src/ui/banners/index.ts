export { SuccessfulMerge } from './successful-merge'
